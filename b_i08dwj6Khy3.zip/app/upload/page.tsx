"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { createClient } from "@/lib/supabase/client"
import type { Category } from "@/lib/types"
import { Upload, Loader2, AlertCircle, CheckCircle2, Link as LinkIcon } from "lucide-react"

export default function UploadPage() {
  const router = useRouter()
  const supabase = createClient()
  
  const [user, setUser] = useState<{ id: string } | null>(null)
  const [categories, setCategories] = useState<Category[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)

  // Form fields
  const [title, setTitle] = useState("")
  const [shortDescription, setShortDescription] = useState("")
  const [description, setDescription] = useState("")
  const [categoryId, setCategoryId] = useState("")
  const [downloadUrl, setDownloadUrl] = useState("")
  const [version, setVersion] = useState("")
  const [fileSize, setFileSize] = useState("")
  const [platform, setPlatform] = useState("Windows")
  const [thumbnailUrl, setThumbnailUrl] = useState("")

  useEffect(() => {
    const init = async () => {
      // Check auth
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) {
        router.push('/auth/login?redirect=/upload')
        return
      }
      setUser({ id: user.id })

      // Fetch categories
      const { data: cats } = await supabase
        .from('categories')
        .select('*')
        .order('name')
      
      if (cats) setCategories(cats)
      setIsLoading(false)
    }
    init()
  }, [supabase, router])

  const generateSlug = (title: string) => {
    return title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '')
      + '-' + Date.now().toString(36)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) return

    setIsSubmitting(true)
    setError(null)

    try {
      // Validate required fields
      if (!title || !downloadUrl || !categoryId) {
        throw new Error('Please fill in all required fields')
      }

      // Validate URL format
      try {
        new URL(downloadUrl)
      } catch {
        throw new Error('Please enter a valid download URL')
      }

      const slug = generateSlug(title)

      const { error: insertError } = await supabase.from('apps').insert({
        title,
        slug,
        short_description: shortDescription || null,
        description: description || null,
        category_id: categoryId,
        user_id: user.id,
        download_url: downloadUrl,
        version: version || null,
        file_size: fileSize || null,
        platform,
        thumbnail_url: thumbnailUrl || null,
        status: 'pending',
      })

      if (insertError) throw insertError

      setSuccess(true)
      setTimeout(() => {
        router.push('/dashboard')
      }, 2000)
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to submit app')
    } finally {
      setIsSubmitting(false)
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    )
  }

  if (!user) {
    return null
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header />
      
      <main className="flex-1 py-8">
        <div className="container mx-auto px-4 max-w-2xl">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="w-5 h-5" />
                Upload New App
              </CardTitle>
              <CardDescription>
                Share your app, game, or software with the AppVault community. All uploads are reviewed before being published.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {success ? (
                <div className="text-center py-8">
                  <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <CheckCircle2 className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold text-foreground mb-2">
                    App Submitted Successfully!
                  </h3>
                  <p className="text-muted-foreground mb-4">
                    Your app is now pending review. {"You'll"} be notified once {"it's"} approved.
                  </p>
                  <Button asChild>
                    <Link href="/dashboard">Go to Dashboard</Link>
                  </Button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  {error && (
                    <div className="p-4 bg-destructive/10 border border-destructive/20 rounded-lg flex items-start gap-3">
                      <AlertCircle className="w-5 h-5 text-destructive flex-shrink-0 mt-0.5" />
                      <p className="text-sm text-destructive">{error}</p>
                    </div>
                  )}

                  {/* Title */}
                  <div className="space-y-2">
                    <Label htmlFor="title">App Name *</Label>
                    <Input
                      id="title"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      placeholder="e.g., Super Game Pro"
                      className="bg-input border-border"
                      required
                    />
                  </div>

                  {/* Category */}
                  <div className="space-y-2">
                    <Label htmlFor="category">Category *</Label>
                    <Select value={categoryId} onValueChange={setCategoryId} required>
                      <SelectTrigger className="bg-input border-border">
                        <SelectValue placeholder="Select a category" />
                      </SelectTrigger>
                      <SelectContent className="bg-popover border-border">
                        {categories.map((cat) => (
                          <SelectItem key={cat.id} value={cat.id}>
                            {cat.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Download URL */}
                  <div className="space-y-2">
                    <Label htmlFor="downloadUrl">Download URL *</Label>
                    <div className="relative">
                      <LinkIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        id="downloadUrl"
                        value={downloadUrl}
                        onChange={(e) => setDownloadUrl(e.target.value)}
                        placeholder="https://mediafire.com/file/..."
                        className="pl-10 bg-input border-border"
                        required
                      />
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Enter a direct download link (MediaFire, Google Drive, Mega, etc.)
                    </p>
                  </div>

                  {/* Short Description */}
                  <div className="space-y-2">
                    <Label htmlFor="shortDescription">Short Description</Label>
                    <Input
                      id="shortDescription"
                      value={shortDescription}
                      onChange={(e) => setShortDescription(e.target.value)}
                      placeholder="A brief one-line description"
                      className="bg-input border-border"
                      maxLength={150}
                    />
                  </div>

                  {/* Full Description */}
                  <div className="space-y-2">
                    <Label htmlFor="description">Full Description</Label>
                    <Textarea
                      id="description"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      placeholder="Detailed description of your app, features, system requirements, etc."
                      className="bg-input border-border min-h-[120px]"
                    />
                  </div>

                  {/* Version & File Size */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="version">Version</Label>
                      <Input
                        id="version"
                        value={version}
                        onChange={(e) => setVersion(e.target.value)}
                        placeholder="e.g., 1.0.0"
                        className="bg-input border-border"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="fileSize">File Size</Label>
                      <Input
                        id="fileSize"
                        value={fileSize}
                        onChange={(e) => setFileSize(e.target.value)}
                        placeholder="e.g., 500 MB"
                        className="bg-input border-border"
                      />
                    </div>
                  </div>

                  {/* Platform */}
                  <div className="space-y-2">
                    <Label htmlFor="platform">Platform</Label>
                    <Select value={platform} onValueChange={setPlatform}>
                      <SelectTrigger className="bg-input border-border">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-popover border-border">
                        <SelectItem value="Windows">Windows</SelectItem>
                        <SelectItem value="macOS">macOS</SelectItem>
                        <SelectItem value="Linux">Linux</SelectItem>
                        <SelectItem value="Android">Android</SelectItem>
                        <SelectItem value="iOS">iOS</SelectItem>
                        <SelectItem value="Web">Web</SelectItem>
                        <SelectItem value="Multi-Platform">Multi-Platform</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Thumbnail URL */}
                  <div className="space-y-2">
                    <Label htmlFor="thumbnailUrl">Thumbnail Image URL</Label>
                    <Input
                      id="thumbnailUrl"
                      value={thumbnailUrl}
                      onChange={(e) => setThumbnailUrl(e.target.value)}
                      placeholder="https://example.com/image.jpg"
                      className="bg-input border-border"
                    />
                    <p className="text-xs text-muted-foreground">
                      Direct link to an image (recommended size: 800x600)
                    </p>
                  </div>

                  {/* Submit */}
                  <Button type="submit" className="w-full" disabled={isSubmitting}>
                    {isSubmitting ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Submitting...
                      </>
                    ) : (
                      <>
                        <Upload className="w-4 h-4 mr-2" />
                        Submit for Review
                      </>
                    )}
                  </Button>
                </form>
              )}
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  )
}
