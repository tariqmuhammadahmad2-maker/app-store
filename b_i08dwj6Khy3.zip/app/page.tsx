import Link from "next/link"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { AppCard } from "@/components/app-card"
import { FeaturedCarousel } from "@/components/featured-carousel"
import { Button } from "@/components/ui/button"
import { getTrendingApps, getRecentApps, getFeaturedApps, getCategories } from "@/lib/queries"
import { ArrowRight, Gamepad2, Monitor, Smartphone, Wrench, Film, Code } from "lucide-react"

const categoryIcons: Record<string, React.ElementType> = {
  games: Gamepad2,
  software: Monitor,
  apps: Smartphone,
  tools: Wrench,
  media: Film,
  development: Code,
}

export default async function Home() {
  const [featuredApps, trendingApps, recentApps, categories] = await Promise.all([
    getFeaturedApps(),
    getTrendingApps(),
    getRecentApps(),
    getCategories(),
  ])

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      
      <main className="flex-1">
        {/* Featured Carousel */}
        <FeaturedCarousel apps={featuredApps} />

        {/* Categories Section */}
        <section className="py-12 border-b border-border">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl font-bold text-foreground mb-6">Browse Categories</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
              {categories.map((category) => {
                const Icon = categoryIcons[category.slug] || Monitor
                return (
                  <Link
                    key={category.id}
                    href={`/browse?category=${category.slug}`}
                    className="group flex flex-col items-center p-6 bg-card rounded-xl border border-border hover:border-primary/50 transition-all duration-300"
                  >
                    <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center mb-3 group-hover:bg-primary/20 transition-colors">
                      <Icon className="w-7 h-7 text-primary" />
                    </div>
                    <span className="font-medium text-foreground group-hover:text-primary transition-colors">
                      {category.name}
                    </span>
                  </Link>
                )
              })}
            </div>
          </div>
        </section>

        {/* Trending Apps Section */}
        {trendingApps.length > 0 && (
          <section className="py-12">
            <div className="container mx-auto px-4">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-foreground">Trending Apps</h2>
                  <p className="text-muted-foreground">Most downloaded apps this week</p>
                </div>
                <Button asChild variant="ghost" className="gap-2">
                  <Link href="/browse?sort=popular">
                    View All <ArrowRight className="w-4 h-4" />
                  </Link>
                </Button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {trendingApps.slice(0, 4).map((app) => (
                  <AppCard key={app.id} app={app} />
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Recent Updates Section */}
        {recentApps.length > 0 && (
          <section className="py-12 bg-card/30">
            <div className="container mx-auto px-4">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-foreground">Recent Updates</h2>
                  <p className="text-muted-foreground">Newly added and updated apps</p>
                </div>
                <Button asChild variant="ghost" className="gap-2">
                  <Link href="/browse?sort=newest">
                    View All <ArrowRight className="w-4 h-4" />
                  </Link>
                </Button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {recentApps.slice(0, 4).map((app) => (
                  <AppCard key={app.id} app={app} />
                ))}
              </div>
            </div>
          </section>
        )}

        {/* CTA Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="bg-gradient-to-r from-primary/20 via-primary/10 to-transparent rounded-2xl p-8 md:p-12 border border-primary/20">
              <div className="max-w-2xl">
                <h2 className="text-3xl font-bold text-foreground mb-4">
                  Share Your Apps with the World
                </h2>
                <p className="text-muted-foreground mb-6">
                  Have an app, game, or software you want to share? Upload it to AppVault and reach thousands of users looking for quality downloads.
                </p>
                <Button asChild size="lg">
                  <Link href="/upload">Upload Your App</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  )
}
