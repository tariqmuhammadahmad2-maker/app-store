import { Suspense } from 'react'
import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { SearchBar } from '@/components/search-bar'
import { CategoryFilter } from '@/components/category-filter'
import { AppCard, AppCardSkeleton } from '@/components/app-card'
import { Pagination } from '@/components/pagination'
import { getApps, getCategories } from '@/lib/queries'
import type { SearchFilters } from '@/lib/types'
import { Search } from 'lucide-react'

interface BrowsePageProps {
  searchParams: Promise<{
    q?: string
    category?: string
    platform?: string
    sort?: string
    page?: string
  }>
}

export default async function BrowsePage({ searchParams }: BrowsePageProps) {
  const params = await searchParams
  
  const filters: SearchFilters = {
    query: params.q,
    category: params.category,
    platform: params.platform,
    sort: (params.sort as 'newest' | 'popular' | 'rating') || 'newest',
    page: parseInt(params.page || '1'),
  }

  const [{ apps, totalCount, totalPages }, categories] = await Promise.all([
    getApps(filters),
    getCategories(),
  ])

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header />
      
      <main className="flex-1">
        <div className="container mx-auto px-4 py-8">
          {/* Page Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-2">
              {params.q ? `Search Results for "${params.q}"` : 'Browse Apps'}
            </h1>
            <p className="text-muted-foreground">
              {totalCount > 0 
                ? `Found ${totalCount} ${totalCount === 1 ? 'app' : 'apps'}`
                : 'Discover and download the best apps, games, and software'}
            </p>
          </div>

          {/* Search & Filters */}
          <div className="space-y-4 mb-8">
            <Suspense fallback={<div className="h-12 bg-secondary animate-pulse rounded-lg" />}>
              <SearchBar />
            </Suspense>
            <Suspense fallback={<div className="h-10 bg-secondary animate-pulse rounded-lg w-96" />}>
              <CategoryFilter currentCategory={params.category || ''} />
            </Suspense>
          </div>

          {/* Results */}
          {apps.length > 0 ? (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-8">
                {apps.map((app) => (
                  <AppCard key={app.id} app={app} />
                ))}
              </div>
              
              {/* Pagination */}
              <Pagination 
                currentPage={filters.page || 1} 
                totalPages={totalPages} 
                className="mt-8"
              />
            </>
          ) : (
            <div className="text-center py-16">
              <div className="w-20 h-20 bg-secondary rounded-full flex items-center justify-center mx-auto mb-6">
                <Search className="w-10 h-10 text-muted-foreground" />
              </div>
              <h2 className="text-xl font-semibold text-foreground mb-2">No apps found</h2>
              <p className="text-muted-foreground max-w-md mx-auto">
                {params.q 
                  ? `We couldn't find any apps matching "${params.q}". Try adjusting your search or filters.`
                  : 'There are no apps in this category yet. Check back later or try a different category.'}
              </p>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  )
}

// Loading state
function LoadingGrid() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {Array.from({ length: 8 }).map((_, i) => (
        <AppCardSkeleton key={i} />
      ))}
    </div>
  )
}
