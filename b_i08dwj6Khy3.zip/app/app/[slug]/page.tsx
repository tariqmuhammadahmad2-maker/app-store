import { notFound } from 'next/navigation'
import Link from 'next/link'
import Image from 'next/image'
import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { StarRating } from '@/components/star-rating'
import { ReviewSection } from '@/components/review-section'
import { DonationSection } from '@/components/donation-section'
import { DownloadButton } from '@/components/download-button'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { getAppBySlug, getAppReviews } from '@/lib/queries'
import { 
  Download, 
  Calendar, 
  HardDrive, 
  Monitor, 
  User, 
  Shield, 
  ExternalLink,
  ChevronLeft,
  Share2
} from 'lucide-react'

interface AppDetailPageProps {
  params: Promise<{ slug: string }>
}

export default async function AppDetailPage({ params }: AppDetailPageProps) {
  const { slug } = await params
  const app = await getAppBySlug(slug)

  if (!app) {
    notFound()
  }

  const reviews = await getAppReviews(app.id)

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    })
  }

  const formatDownloads = (count: number) => {
    if (count >= 1000000) return `${(count / 1000000).toFixed(1)}M`
    if (count >= 1000) return `${(count / 1000).toFixed(1)}K`
    return count.toString()
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Hero Section */}
        <div className="relative h-64 md:h-80 w-full overflow-hidden">
          {app.thumbnail_url ? (
            <Image
              src={app.thumbnail_url}
              alt={app.title}
              fill
              className="object-cover"
              priority
              crossOrigin="anonymous"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-primary/30 to-secondary" />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
        </div>

        <div className="container mx-auto px-4 -mt-24 relative z-10">
          {/* Back Button */}
          <Button asChild variant="ghost" size="sm" className="mb-4">
            <Link href="/browse" className="gap-2">
              <ChevronLeft className="w-4 h-4" />
              Back to Browse
            </Link>
          </Button>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* App Header Card */}
              <Card className="bg-card border-border">
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row gap-6">
                    {/* App Icon */}
                    <div className="relative w-24 h-24 md:w-32 md:h-32 rounded-2xl overflow-hidden bg-secondary flex-shrink-0">
                      {app.thumbnail_url ? (
                        <Image
                          src={app.thumbnail_url}
                          alt={app.title}
                          fill
                          className="object-cover"
                          crossOrigin="anonymous"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-primary/20">
                          <Download className="w-12 h-12 text-primary" />
                        </div>
                      )}
                    </div>

                    {/* App Info */}
                    <div className="flex-1">
                      <div className="flex items-start justify-between gap-4 mb-2">
                        <h1 className="text-2xl md:text-3xl font-bold text-foreground">
                          {app.title}
                        </h1>
                        {app.status === 'approved' && (
                          <Badge className="bg-primary/20 text-primary border-primary/30 gap-1">
                            <Shield className="w-3 h-3" />
                            Verified
                          </Badge>
                        )}
                      </div>

                      <div className="flex flex-wrap items-center gap-3 mb-4">
                        <Badge variant="secondary">{app.category?.name || 'App'}</Badge>
                        {app.average_rating && (
                          <div className="flex items-center gap-2">
                            <StarRating rating={app.average_rating} size="sm" />
                            <span className="text-sm text-muted-foreground">
                              ({app.review_count} reviews)
                            </span>
                          </div>
                        )}
                      </div>

                      <p className="text-muted-foreground mb-4">
                        {app.short_description || 'No description available'}
                      </p>

                      <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <User className="w-4 h-4" />
                          {app.user?.display_name || app.user?.username || 'Anonymous'}
                        </span>
                        <span className="flex items-center gap-1">
                          <Download className="w-4 h-4" />
                          {formatDownloads(app.download_count)} downloads
                        </span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Description */}
              {app.description && (
                <Card className="bg-card border-border">
                  <CardContent className="p-6">
                    <h2 className="text-xl font-semibold text-foreground mb-4">About</h2>
                    <div className="prose prose-invert max-w-none">
                      <p className="text-muted-foreground whitespace-pre-wrap">
                        {app.description}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Screenshots */}
              {app.screenshots && app.screenshots.length > 0 && (
                <Card className="bg-card border-border">
                  <CardContent className="p-6">
                    <h2 className="text-xl font-semibold text-foreground mb-4">Screenshots</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {app.screenshots.map((screenshot, index) => (
                        <div key={index} className="relative aspect-video rounded-lg overflow-hidden bg-secondary">
                          <Image
                            src={screenshot}
                            alt={`${app.title} screenshot ${index + 1}`}
                            fill
                            className="object-cover"
                            crossOrigin="anonymous"
                          />
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Reviews Section */}
              <ReviewSection appId={app.id} reviews={reviews} />
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Download Card */}
              <Card className="bg-card border-border sticky top-20">
                <CardContent className="p-6 space-y-4">
                  <DownloadButton app={app} />

                  <div className="grid grid-cols-2 gap-4 pt-4 border-t border-border">
                    <div>
                      <span className="text-xs text-muted-foreground block mb-1">Version</span>
                      <span className="text-sm font-medium text-foreground">{app.version || 'N/A'}</span>
                    </div>
                    <div>
                      <span className="text-xs text-muted-foreground block mb-1">Size</span>
                      <span className="text-sm font-medium text-foreground">{app.file_size || 'N/A'}</span>
                    </div>
                    <div>
                      <span className="text-xs text-muted-foreground block mb-1">Platform</span>
                      <span className="text-sm font-medium text-foreground flex items-center gap-1">
                        <Monitor className="w-3 h-3" />
                        {app.platform}
                      </span>
                    </div>
                    <div>
                      <span className="text-xs text-muted-foreground block mb-1">Updated</span>
                      <span className="text-sm font-medium text-foreground flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {formatDate(app.updated_at)}
                      </span>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-border">
                    <Button variant="outline" className="w-full gap-2" asChild>
                      <a href={app.download_url} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="w-4 h-4" />
                        View Source
                      </a>
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Donation Section */}
              <DonationSection appId={app.id} appTitle={app.title} />
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
