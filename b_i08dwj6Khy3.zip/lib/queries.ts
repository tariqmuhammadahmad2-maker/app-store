import { createClient } from '@/lib/supabase/server'
import type { App, Category, Review, SearchFilters } from '@/lib/types'

const ITEMS_PER_PAGE = 12

export async function getCategories(): Promise<Category[]> {
  const supabase = await createClient()
  const { data, error } = await supabase
    .from('categories')
    .select('*')
    .order('name')
  
  if (error) {
    console.error('Error fetching categories:', error)
    return []
  }
  
  return data || []
}

export async function getApps(filters: SearchFilters = {}): Promise<{
  apps: App[]
  totalCount: number
  totalPages: number
}> {
  const supabase = await createClient()
  const page = filters.page || 1
  const limit = filters.limit || ITEMS_PER_PAGE
  const offset = (page - 1) * limit

  let query = supabase
    .from('apps')
    .select(`
      *,
      category:categories(*),
      user:profiles(id, username, display_name, avatar_url)
    `, { count: 'exact' })
    .eq('status', 'approved')

  // Apply search filter
  if (filters.query) {
    query = query.or(`title.ilike.%${filters.query}%,description.ilike.%${filters.query}%,short_description.ilike.%${filters.query}%`)
  }

  // Apply category filter
  if (filters.category) {
    const { data: categoryData } = await supabase
      .from('categories')
      .select('id')
      .eq('slug', filters.category)
      .single()
    
    if (categoryData) {
      query = query.eq('category_id', categoryData.id)
    }
  }

  // Apply platform filter
  if (filters.platform) {
    query = query.eq('platform', filters.platform)
  }

  // Apply sorting
  switch (filters.sort) {
    case 'popular':
      query = query.order('download_count', { ascending: false })
      break
    case 'rating':
      query = query.order('download_count', { ascending: false }) // TODO: Add rating sort
      break
    case 'newest':
    default:
      query = query.order('created_at', { ascending: false })
  }

  // Apply pagination
  query = query.range(offset, offset + limit - 1)

  const { data, error, count } = await query

  if (error) {
    console.error('Error fetching apps:', error)
    return { apps: [], totalCount: 0, totalPages: 0 }
  }

  // Calculate average ratings for each app
  const appsWithRatings = await Promise.all(
    (data || []).map(async (app) => {
      const { data: reviewData } = await supabase
        .from('reviews')
        .select('rating')
        .eq('app_id', app.id)
      
      const ratings = reviewData || []
      const average_rating = ratings.length > 0
        ? ratings.reduce((sum, r) => sum + r.rating, 0) / ratings.length
        : null
      
      return {
        ...app,
        average_rating,
        review_count: ratings.length,
      }
    })
  )

  return {
    apps: appsWithRatings as App[],
    totalCount: count || 0,
    totalPages: Math.ceil((count || 0) / limit),
  }
}

export async function getFeaturedApps(): Promise<App[]> {
  const supabase = await createClient()
  
  const { data, error } = await supabase
    .from('apps')
    .select(`
      *,
      category:categories(*),
      user:profiles(id, username, display_name, avatar_url)
    `)
    .eq('status', 'approved')
    .eq('is_featured', true)
    .order('created_at', { ascending: false })
    .limit(6)

  if (error) {
    console.error('Error fetching featured apps:', error)
    return []
  }

  return data as App[]
}

export async function getTrendingApps(): Promise<App[]> {
  const supabase = await createClient()
  
  const { data, error } = await supabase
    .from('apps')
    .select(`
      *,
      category:categories(*),
      user:profiles(id, username, display_name, avatar_url)
    `)
    .eq('status', 'approved')
    .order('download_count', { ascending: false })
    .limit(8)

  if (error) {
    console.error('Error fetching trending apps:', error)
    return []
  }

  return data as App[]
}

export async function getRecentApps(): Promise<App[]> {
  const supabase = await createClient()
  
  const { data, error } = await supabase
    .from('apps')
    .select(`
      *,
      category:categories(*),
      user:profiles(id, username, display_name, avatar_url)
    `)
    .eq('status', 'approved')
    .order('created_at', { ascending: false })
    .limit(8)

  if (error) {
    console.error('Error fetching recent apps:', error)
    return []
  }

  return data as App[]
}

export async function getAppBySlug(slug: string): Promise<App | null> {
  const supabase = await createClient()
  
  const { data, error } = await supabase
    .from('apps')
    .select(`
      *,
      category:categories(*),
      user:profiles(id, username, display_name, avatar_url)
    `)
    .eq('slug', slug)
    .single()

  if (error) {
    console.error('Error fetching app:', error)
    return null
  }

  // Get average rating
  const { data: reviewData } = await supabase
    .from('reviews')
    .select('rating')
    .eq('app_id', data.id)
  
  const ratings = reviewData || []
  const average_rating = ratings.length > 0
    ? ratings.reduce((sum, r) => sum + r.rating, 0) / ratings.length
    : null

  return {
    ...data,
    average_rating,
    review_count: ratings.length,
  } as App
}

export async function getAppReviews(appId: string): Promise<Review[]> {
  const supabase = await createClient()
  
  const { data, error } = await supabase
    .from('reviews')
    .select(`
      *,
      user:profiles(id, username, display_name, avatar_url)
    `)
    .eq('app_id', appId)
    .order('created_at', { ascending: false })

  if (error) {
    console.error('Error fetching reviews:', error)
    return []
  }

  return data as Review[]
}

export async function getUserApps(userId: string): Promise<App[]> {
  const supabase = await createClient()
  
  const { data, error } = await supabase
    .from('apps')
    .select(`
      *,
      category:categories(*)
    `)
    .eq('user_id', userId)
    .order('created_at', { ascending: false })

  if (error) {
    console.error('Error fetching user apps:', error)
    return []
  }

  return data as App[]
}

export async function getPendingApps(): Promise<App[]> {
  const supabase = await createClient()
  
  const { data, error } = await supabase
    .from('apps')
    .select(`
      *,
      category:categories(*),
      user:profiles(id, username, display_name, avatar_url)
    `)
    .eq('status', 'pending')
    .order('created_at', { ascending: false })

  if (error) {
    console.error('Error fetching pending apps:', error)
    return []
  }

  return data as App[]
}
