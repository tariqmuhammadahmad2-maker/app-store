export interface Profile {
  id: string
  username: string | null
  display_name: string | null
  avatar_url: string | null
  bio: string | null
  is_admin: boolean
  created_at: string
  updated_at: string
}

export interface Category {
  id: string
  name: string
  slug: string
  description: string | null
  icon: string | null
  created_at: string
}

export interface App {
  id: string
  title: string
  slug: string
  description: string | null
  short_description: string | null
  category_id: string | null
  user_id: string
  download_url: string
  version: string | null
  file_size: string | null
  platform: string
  thumbnail_url: string | null
  screenshots: string[] | null
  status: 'pending' | 'approved' | 'rejected'
  rejection_reason: string | null
  download_count: number
  is_featured: boolean
  created_at: string
  updated_at: string
  // Joined fields
  category?: Category
  user?: Profile
  average_rating?: number
  review_count?: number
}

export interface Review {
  id: string
  app_id: string
  user_id: string
  rating: number
  comment: string | null
  created_at: string
  updated_at: string
  // Joined fields
  user?: Profile
}

export interface Download {
  id: string
  app_id: string
  user_id: string | null
  ip_address: string | null
  created_at: string
}

export interface Donation {
  id: string
  app_id: string
  donor_id: string | null
  amount: number
  currency: string
  message: string | null
  is_anonymous: boolean
  created_at: string
  // Joined fields
  donor?: Profile
}

export interface SearchFilters {
  query?: string
  category?: string
  platform?: string
  sort?: 'newest' | 'popular' | 'rating'
  page?: number
  limit?: number
}
