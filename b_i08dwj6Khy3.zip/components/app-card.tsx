"use client"

import Link from "next/link"
import Image from "next/image"
import { Download, Star, Clock, Shield } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import type { App } from "@/lib/types"

interface AppCardProps {
  app: App
  variant?: 'default' | 'compact' | 'featured'
}

export function AppCard({ app, variant = 'default' }: AppCardProps) {
  const formatDownloads = (count: number) => {
    if (count >= 1000000) return `${(count / 1000000).toFixed(1)}M`
    if (count >= 1000) return `${(count / 1000).toFixed(1)}K`
    return count.toString()
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
    })
  }

  if (variant === 'compact') {
    return (
      <Link href={`/app/${app.slug}`}>
        <Card className="group bg-card border-border hover:border-primary/50 transition-all duration-300 overflow-hidden">
          <CardContent className="p-3 flex items-center gap-3">
            <div className="relative w-12 h-12 rounded-lg overflow-hidden bg-secondary flex-shrink-0">
              {app.thumbnail_url ? (
                <Image
                  src={app.thumbnail_url}
                  alt={app.title}
                  fill
                  className="object-cover"
                  crossOrigin="anonymous"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-primary/20">
                  <Download className="w-6 h-6 text-primary" />
                </div>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-medium text-foreground truncate group-hover:text-primary transition-colors">
                {app.title}
              </h3>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span>{app.category?.name || 'Uncategorized'}</span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <Download className="w-3 h-3" />
                  {formatDownloads(app.download_count)}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </Link>
    )
  }

  if (variant === 'featured') {
    return (
      <Link href={`/app/${app.slug}`}>
        <Card className="group relative bg-card border-border hover:border-primary/50 transition-all duration-300 overflow-hidden h-full">
          <div className="relative aspect-video w-full overflow-hidden">
            {app.thumbnail_url ? (
              <Image
                src={app.thumbnail_url}
                alt={app.title}
                fill
                className="object-cover group-hover:scale-105 transition-transform duration-500"
                crossOrigin="anonymous"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/30 to-secondary">
                <Download className="w-16 h-16 text-primary/50" />
              </div>
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent" />
            {app.is_featured && (
              <Badge className="absolute top-3 left-3 bg-primary text-primary-foreground">
                Featured
              </Badge>
            )}
          </div>
          <CardContent className="p-5">
            <div className="flex items-start justify-between gap-2 mb-2">
              <h3 className="font-semibold text-lg text-foreground group-hover:text-primary transition-colors line-clamp-1">
                {app.title}
              </h3>
              {app.status === 'approved' && (
                <Shield className="w-4 h-4 text-primary flex-shrink-0" />
              )}
            </div>
            <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
              {app.short_description || app.description || 'No description available'}
            </p>
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-3 text-muted-foreground">
                <span className="flex items-center gap-1">
                  <Download className="w-4 h-4" />
                  {formatDownloads(app.download_count)}
                </span>
                {app.average_rating && (
                  <span className="flex items-center gap-1">
                    <Star className="w-4 h-4 fill-chart-4 text-chart-4" />
                    {app.average_rating.toFixed(1)}
                  </span>
                )}
              </div>
              <Badge variant="secondary">{app.category?.name || 'App'}</Badge>
            </div>
          </CardContent>
        </Card>
      </Link>
    )
  }

  // Default variant
  return (
    <Link href={`/app/${app.slug}`}>
      <Card className="group relative bg-card border-border hover:border-primary/50 transition-all duration-300 overflow-hidden h-full">
        <div className="relative aspect-[4/3] w-full overflow-hidden">
          {app.thumbnail_url ? (
            <Image
              src={app.thumbnail_url}
              alt={app.title}
              fill
              className="object-cover group-hover:scale-105 transition-transform duration-500"
              crossOrigin="anonymous"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/20 to-secondary">
              <Download className="w-12 h-12 text-primary/50" />
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent opacity-80" />
          <Badge className="absolute top-3 left-3 bg-secondary/90 text-secondary-foreground">
            {app.category?.name || 'App'}
          </Badge>
          {app.version && (
            <Badge variant="outline" className="absolute top-3 right-3 bg-card/80 border-border">
              v{app.version}
            </Badge>
          )}
        </div>
        <CardContent className="p-4">
          <div className="flex items-start justify-between gap-2 mb-2">
            <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors line-clamp-1">
              {app.title}
            </h3>
            {app.status === 'approved' && (
              <Shield className="w-4 h-4 text-primary flex-shrink-0" title="Verified" />
            )}
          </div>
          <p className="text-xs text-muted-foreground line-clamp-2 mb-3 min-h-[2rem]">
            {app.short_description || 'No description available'}
          </p>
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1">
                <Download className="w-3.5 h-3.5" />
                {formatDownloads(app.download_count)}
              </span>
              {app.average_rating && (
                <span className="flex items-center gap-1">
                  <Star className="w-3.5 h-3.5 fill-chart-4 text-chart-4" />
                  {app.average_rating.toFixed(1)}
                </span>
              )}
            </div>
            <div className="flex items-center gap-2">
              {app.file_size && <span>{app.file_size}</span>}
              <span className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                {formatDate(app.created_at)}
              </span>
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}

// Skeleton loader for app cards
export function AppCardSkeleton({ variant = 'default' }: { variant?: 'default' | 'compact' | 'featured' }) {
  if (variant === 'compact') {
    return (
      <Card className="bg-card border-border">
        <CardContent className="p-3 flex items-center gap-3">
          <div className="w-12 h-12 rounded-lg bg-secondary animate-pulse" />
          <div className="flex-1">
            <div className="h-4 bg-secondary rounded animate-pulse mb-2 w-3/4" />
            <div className="h-3 bg-secondary rounded animate-pulse w-1/2" />
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="bg-card border-border overflow-hidden">
      <div className={`${variant === 'featured' ? 'aspect-video' : 'aspect-[4/3]'} bg-secondary animate-pulse`} />
      <CardContent className="p-4">
        <div className="h-5 bg-secondary rounded animate-pulse mb-2 w-3/4" />
        <div className="h-3 bg-secondary rounded animate-pulse mb-1 w-full" />
        <div className="h-3 bg-secondary rounded animate-pulse mb-3 w-2/3" />
        <div className="flex justify-between">
          <div className="h-3 bg-secondary rounded animate-pulse w-1/4" />
          <div className="h-3 bg-secondary rounded animate-pulse w-1/4" />
        </div>
      </CardContent>
    </Card>
  )
}
