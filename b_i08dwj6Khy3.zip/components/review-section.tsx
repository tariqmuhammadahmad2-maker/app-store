"use client"

import { useState, useEffect } from "react"
import { StarRating } from "@/components/star-rating"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import { createClient } from "@/lib/supabase/client"
import type { Review, Profile } from "@/lib/types"
import { User, Loader2 } from "lucide-react"

interface ReviewSectionProps {
  appId: string
  reviews: Review[]
}

export function ReviewSection({ appId, reviews: initialReviews }: ReviewSectionProps) {
  const [reviews, setReviews] = useState<Review[]>(initialReviews)
  const [user, setUser] = useState<{ id: string } | null>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [rating, setRating] = useState(0)
  const [comment, setComment] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [hasReviewed, setHasReviewed] = useState(false)
  const supabase = createClient()

  useEffect(() => {
    const getUser = async () => {
      const { data: { user } } = await supabase.auth.getUser()
      if (user) {
        setUser({ id: user.id })
        const { data: profile } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single()
        if (profile) setProfile(profile)

        // Check if user already reviewed
        const existingReview = initialReviews.find(r => r.user_id === user.id)
        if (existingReview) {
          setHasReviewed(true)
          setRating(existingReview.rating)
          setComment(existingReview.comment || '')
        }
      }
    }
    getUser()
  }, [supabase, appId, initialReviews])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user || rating === 0) return

    setIsSubmitting(true)
    setError(null)

    try {
      if (hasReviewed) {
        // Update existing review
        const { error } = await supabase
          .from('reviews')
          .update({ rating, comment, updated_at: new Date().toISOString() })
          .eq('app_id', appId)
          .eq('user_id', user.id)

        if (error) throw error
      } else {
        // Create new review
        const { error } = await supabase
          .from('reviews')
          .insert({ app_id: appId, user_id: user.id, rating, comment })

        if (error) throw error
        setHasReviewed(true)
      }

      // Refresh reviews
      const { data: newReviews } = await supabase
        .from('reviews')
        .select('*, user:profiles(id, username, display_name, avatar_url)')
        .eq('app_id', appId)
        .order('created_at', { ascending: false })

      if (newReviews) setReviews(newReviews as Review[])
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to submit review')
    } finally {
      setIsSubmitting(false)
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    })
  }

  return (
    <Card className="bg-card border-border">
      <CardContent className="p-6">
        <h2 className="text-xl font-semibold text-foreground mb-6">Reviews</h2>

        {/* Review Form */}
        {user ? (
          <form onSubmit={handleSubmit} className="mb-8 p-4 bg-secondary/30 rounded-lg">
            <h3 className="font-medium text-foreground mb-3">
              {hasReviewed ? 'Update Your Review' : 'Write a Review'}
            </h3>
            
            <div className="mb-4">
              <label className="text-sm text-muted-foreground block mb-2">Your Rating</label>
              <StarRating rating={rating} interactive onChange={setRating} size="lg" />
            </div>

            <div className="mb-4">
              <label className="text-sm text-muted-foreground block mb-2">Your Review (optional)</label>
              <Textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Share your experience with this app..."
                className="bg-input border-border"
                rows={3}
              />
            </div>

            {error && (
              <p className="text-destructive text-sm mb-4">{error}</p>
            )}

            <Button type="submit" disabled={isSubmitting || rating === 0}>
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Submitting...
                </>
              ) : hasReviewed ? (
                'Update Review'
              ) : (
                'Submit Review'
              )}
            </Button>
          </form>
        ) : (
          <div className="mb-8 p-4 bg-secondary/30 rounded-lg text-center">
            <p className="text-muted-foreground">
              <a href="/auth/login" className="text-primary hover:underline">Sign in</a> to leave a review
            </p>
          </div>
        )}

        {/* Reviews List */}
        {reviews.length > 0 ? (
          <div className="space-y-4">
            {reviews.map((review) => (
              <div key={review.id} className="p-4 bg-secondary/20 rounded-lg">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                    <User className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium text-foreground">
                        {review.user?.display_name || review.user?.username || 'Anonymous'}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {formatDate(review.created_at)}
                      </span>
                    </div>
                    <StarRating rating={review.rating} size="sm" className="mb-2" />
                    {review.comment && (
                      <p className="text-sm text-muted-foreground">{review.comment}</p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-center text-muted-foreground py-8">
            No reviews yet. Be the first to review!
          </p>
        )}
      </CardContent>
    </Card>
  )
}
