"use client"

import { useCallback, useEffect, useState } from "react"
import Link from "next/link"
import Image from "next/image"
import useEmblaCarousel from "embla-carousel-react"
import Autoplay from "embla-carousel-autoplay"
import { ChevronLeft, ChevronRight, Download, Star, TrendingUp, Upload } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import type { App } from "@/lib/types"

interface FeaturedCarouselProps {
  apps: App[]
}

// Default featured items when no apps are available
const defaultItems = [
  {
    id: 'cta-1',
    title: "Welcome to AppVault",
    description: "Your one-stop destination for games, software, and apps. Browse our collection or upload your own creations.",
    image: "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=1200&h=600&fit=crop",
    isCallToAction: true,
  },
  {
    id: 'cta-2',
    title: "Share Your Apps",
    description: "Have an amazing app or game? Upload it to AppVault and share it with thousands of users worldwide.",
    image: "https://images.unsplash.com/photo-1626785774573-4b799315345d?w=1200&h=600&fit=crop",
    isCallToAction: true,
  },
]

export function FeaturedCarousel({ apps }: FeaturedCarouselProps) {
  const items = apps.length > 0 ? apps : defaultItems
  
  const [emblaRef, emblaApi] = useEmblaCarousel({ loop: true }, [
    Autoplay({ delay: 5000, stopOnInteraction: false })
  ])
  const [selectedIndex, setSelectedIndex] = useState(0)

  const scrollPrev = useCallback(() => {
    if (emblaApi) emblaApi.scrollPrev()
  }, [emblaApi])

  const scrollNext = useCallback(() => {
    if (emblaApi) emblaApi.scrollNext()
  }, [emblaApi])

  const scrollTo = useCallback((index: number) => {
    if (emblaApi) emblaApi.scrollTo(index)
  }, [emblaApi])

  const onSelect = useCallback(() => {
    if (!emblaApi) return
    setSelectedIndex(emblaApi.selectedScrollSnap())
  }, [emblaApi])

  useEffect(() => {
    if (!emblaApi) return
    onSelect()
    emblaApi.on("select", onSelect)
    return () => {
      emblaApi.off("select", onSelect)
    }
  }, [emblaApi, onSelect])

  const formatDownloads = (count: number) => {
    if (count >= 1000000) return `${(count / 1000000).toFixed(1)}M`
    if (count >= 1000) return `${(count / 1000).toFixed(1)}K`
    return count.toString()
  }

  return (
    <section className="relative w-full">
      <div className="overflow-hidden" ref={emblaRef}>
        <div className="flex">
          {items.map((item) => {
            const isApp = 'slug' in item
            const app = isApp ? (item as App) : null
            const cta = !isApp ? (item as typeof defaultItems[0]) : null

            return (
              <div key={item.id} className="flex-[0_0_100%] min-w-0">
                <div className="relative h-[400px] md:h-[500px] w-full">
                  {/* Background Image */}
                  <div className="absolute inset-0">
                    {app?.thumbnail_url ? (
                      <Image
                        src={app.thumbnail_url}
                        alt={app.title}
                        fill
                        className="object-cover"
                        priority
                        crossOrigin="anonymous"
                      />
                    ) : cta?.image ? (
                      <Image
                        src={cta.image}
                        alt={cta.title}
                        fill
                        className="object-cover"
                        priority
                        crossOrigin="anonymous"
                      />
                    ) : (
                      <div className="w-full h-full bg-gradient-to-br from-primary/30 to-secondary" />
                    )}
                    <div className="absolute inset-0 bg-gradient-to-r from-background via-background/80 to-transparent" />
                    <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
                  </div>

                  {/* Content */}
                  <div className="relative h-full container mx-auto px-4 flex items-center">
                    <div className="max-w-2xl">
                      <Badge variant="secondary" className="mb-4 bg-primary/20 text-primary border-primary/30">
                        {app ? 'Featured' : 'Welcome'}
                      </Badge>
                      <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-4 text-balance">
                        {app?.title || cta?.title}
                      </h2>
                      <p className="text-muted-foreground text-base md:text-lg mb-6 line-clamp-2">
                        {app?.short_description || app?.description || cta?.description}
                      </p>
                      
                      {app && (
                        <div className="flex flex-wrap items-center gap-4 mb-6">
                          <Badge variant="outline" className="text-foreground border-border">
                            {app.category?.name || 'App'}
                          </Badge>
                          {app.average_rating && (
                            <div className="flex items-center gap-1 text-chart-4">
                              <Star className="h-4 w-4 fill-current" />
                              <span className="text-sm font-medium">{app.average_rating.toFixed(1)}</span>
                            </div>
                          )}
                          <span className="text-sm text-muted-foreground flex items-center gap-1">
                            <TrendingUp className="h-4 w-4" />
                            {formatDownloads(app.download_count)} downloads
                          </span>
                          {app.file_size && (
                            <span className="text-sm text-muted-foreground">{app.file_size}</span>
                          )}
                        </div>
                      )}

                      {app ? (
                        <Button asChild size="lg" className="gap-2">
                          <Link href={`/app/${app.slug}`}>
                            <Download className="h-5 w-5" />
                            Download Now
                          </Link>
                        </Button>
                      ) : (
                        <div className="flex gap-4">
                          <Button asChild size="lg" className="gap-2">
                            <Link href="/browse">
                              <Download className="h-5 w-5" />
                              Browse Apps
                            </Link>
                          </Button>
                          <Button asChild size="lg" variant="outline" className="gap-2">
                            <Link href="/upload">
                              <Upload className="h-5 w-5" />
                              Upload App
                            </Link>
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Navigation Arrows */}
      {items.length > 1 && (
        <>
          <button
            onClick={scrollPrev}
            className="absolute left-4 top-1/2 -translate-y-1/2 h-12 w-12 rounded-full bg-background/80 backdrop-blur border border-border flex items-center justify-center text-foreground hover:bg-secondary transition-colors"
          >
            <ChevronLeft className="h-6 w-6" />
          </button>
          <button
            onClick={scrollNext}
            className="absolute right-4 top-1/2 -translate-y-1/2 h-12 w-12 rounded-full bg-background/80 backdrop-blur border border-border flex items-center justify-center text-foreground hover:bg-secondary transition-colors"
          >
            <ChevronRight className="h-6 w-6" />
          </button>

          {/* Dots */}
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2">
            {items.map((_, index) => (
              <button
                key={index}
                onClick={() => scrollTo(index)}
                className={`h-2 rounded-full transition-all ${
                  index === selectedIndex
                    ? "w-8 bg-primary"
                    : "w-2 bg-muted-foreground/40 hover:bg-muted-foreground/60"
                }`}
              />
            ))}
          </div>
        </>
      )}
    </section>
  )
}
