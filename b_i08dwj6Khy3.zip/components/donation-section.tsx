"use client"

import { useState, useEffect } from "react"
import { Heart, Loader2, DollarSign } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { createClient } from "@/lib/supabase/client"
import type { Donation } from "@/lib/types"

interface DonationSectionProps {
  appId: string
  appTitle: string
}

const presetAmounts = [5, 10, 25, 50]

export function DonationSection({ appId, appTitle }: DonationSectionProps) {
  const [user, setUser] = useState<{ id: string } | null>(null)
  const [amount, setAmount] = useState<number | string>(10)
  const [message, setMessage] = useState("")
  const [isAnonymous, setIsAnonymous] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [success, setSuccess] = useState(false)
  const [recentDonations, setRecentDonations] = useState<Donation[]>([])
  const supabase = createClient()

  useEffect(() => {
    const init = async () => {
      // Get current user
      const { data: { user } } = await supabase.auth.getUser()
      if (user) setUser({ id: user.id })

      // Get recent donations
      const { data: donations } = await supabase
        .from('donations')
        .select('*, donor:profiles(display_name, username)')
        .eq('app_id', appId)
        .order('created_at', { ascending: false })
        .limit(5)

      if (donations) setRecentDonations(donations as Donation[])
    }
    init()
  }, [supabase, appId])

  const handleDonate = async () => {
    const donationAmount = typeof amount === 'string' ? parseFloat(amount) : amount
    if (!donationAmount || donationAmount <= 0) return

    setIsSubmitting(true)
    
    try {
      const { error } = await supabase.from('donations').insert({
        app_id: appId,
        donor_id: user?.id || null,
        amount: donationAmount,
        message: message || null,
        is_anonymous: isAnonymous,
      })

      if (error) throw error
      
      setSuccess(true)
      setMessage("")
      
      // Refresh donations
      const { data: donations } = await supabase
        .from('donations')
        .select('*, donor:profiles(display_name, username)')
        .eq('app_id', appId)
        .order('created_at', { ascending: false })
        .limit(5)

      if (donations) setRecentDonations(donations as Donation[])
      
      setTimeout(() => setSuccess(false), 3000)
    } catch (err) {
      console.error('Donation error:', err)
    } finally {
      setIsSubmitting(false)
    }
  }

  const totalDonations = recentDonations.reduce((sum, d) => sum + Number(d.amount), 0)

  return (
    <Card className="bg-card border-border">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg flex items-center gap-2">
          <Heart className="w-5 h-5 text-destructive" />
          Support the Developer
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground">
          Love {appTitle}? Show your appreciation with a donation!
        </p>

        {/* Preset Amounts */}
        <div className="grid grid-cols-4 gap-2">
          {presetAmounts.map((preset) => (
            <Button
              key={preset}
              variant={amount === preset ? "default" : "outline"}
              size="sm"
              onClick={() => setAmount(preset)}
              className="text-sm"
            >
              ${preset}
            </Button>
          ))}
        </div>

        {/* Custom Amount */}
        <div className="relative">
          <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            type="number"
            placeholder="Custom amount"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="pl-8 bg-input border-border"
            min="1"
            step="1"
          />
        </div>

        {/* Message */}
        <Textarea
          placeholder="Leave a message (optional)"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          className="bg-input border-border"
          rows={2}
        />

        {/* Anonymous Checkbox */}
        <div className="flex items-center gap-2">
          <Checkbox
            id="anonymous"
            checked={isAnonymous}
            onCheckedChange={(checked) => setIsAnonymous(checked === true)}
          />
          <Label htmlFor="anonymous" className="text-sm text-muted-foreground">
            Make donation anonymous
          </Label>
        </div>

        {/* Donate Button */}
        <Button 
          onClick={handleDonate} 
          className="w-full gap-2"
          disabled={isSubmitting || !amount}
        >
          {isSubmitting ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Processing...
            </>
          ) : success ? (
            <>
              <Heart className="w-4 h-4 fill-current" />
              Thank You!
            </>
          ) : (
            <>
              <Heart className="w-4 h-4" />
              Donate ${typeof amount === 'string' ? parseFloat(amount) || 0 : amount}
            </>
          )}
        </Button>

        {/* Recent Donations */}
        {recentDonations.length > 0 && (
          <div className="pt-4 border-t border-border">
            <h4 className="text-sm font-medium text-foreground mb-3">Recent Supporters</h4>
            <div className="space-y-2">
              {recentDonations.slice(0, 3).map((donation) => (
                <div key={donation.id} className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">
                    {donation.is_anonymous 
                      ? 'Anonymous' 
                      : donation.donor?.display_name || donation.donor?.username || 'Someone'}
                  </span>
                  <span className="text-primary font-medium">${Number(donation.amount).toFixed(0)}</span>
                </div>
              ))}
            </div>
            <p className="text-xs text-muted-foreground mt-3">
              Total: ${totalDonations.toFixed(0)} from {recentDonations.length} supporters
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
