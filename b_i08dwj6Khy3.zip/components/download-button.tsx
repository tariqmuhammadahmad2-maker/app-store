"use client"

import { useState } from "react"
import { Download, Loader2, ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"
import { createClient } from "@/lib/supabase/client"
import type { App } from "@/lib/types"

interface DownloadButtonProps {
  app: App
}

export function DownloadButton({ app }: DownloadButtonProps) {
  const [isLoading, setIsLoading] = useState(false)
  const supabase = createClient()

  const handleDownload = async () => {
    setIsLoading(true)
    
    try {
      // Get current user
      const { data: { user } } = await supabase.auth.getUser()
      
      // Record the download
      await supabase.from('downloads').insert({
        app_id: app.id,
        user_id: user?.id || null,
      })

      // Open download URL in new tab
      window.open(app.download_url, '_blank', 'noopener,noreferrer')
    } catch (error) {
      console.error('Download error:', error)
      // Still open the download even if tracking fails
      window.open(app.download_url, '_blank', 'noopener,noreferrer')
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Button 
      onClick={handleDownload} 
      className="w-full gap-2 h-12 text-base"
      disabled={isLoading}
    >
      {isLoading ? (
        <>
          <Loader2 className="w-5 h-5 animate-spin" />
          Preparing...
        </>
      ) : (
        <>
          <Download className="w-5 h-5" />
          Download Now
        </>
      )}
    </Button>
  )
}
