"use client"

import { useState } from "react"
import { AppCard, AppData } from "./app-card"
import { CategoryFilter } from "./category-filter"
import { TrendingUp, Clock } from "lucide-react"

const trendingApps: AppData[] = [
  {
    id: 1,
    title: "Cyberpunk 2077",
    image: "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&h=500&fit=crop",
    category: "Games",
    version: "v1.6",
    year: 2020,
    size: "70 GB",
    isVerified: true
  },
  {
    id: 2,
    title: "The Witcher 3 Wild Hunt",
    image: "https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=800&h=500&fit=crop",
    category: "Games",
    version: "Original",
    year: 2015,
    size: "50 GB",
    isVerified: true
  },
  {
    id: 3,
    title: "Visual Studio Code",
    image: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=800&h=500&fit=crop",
    category: "Software",
    version: "v1.85",
    year: 2024,
    size: "350 MB",
    isVerified: true
  },
  {
    id: 4,
    title: "Adobe Photoshop 2024",
    image: "https://images.unsplash.com/photo-1626785774573-4b799315345d?w=800&h=500&fit=crop",
    category: "Software",
    version: "v25.0",
    year: 2024,
    size: "4 GB",
    isVerified: true
  },
  {
    id: 5,
    title: "Grand Theft Auto V",
    image: "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=800&h=500&fit=crop",
    category: "Games",
    version: "v1.0.231",
    year: 2013,
    size: "80 GB",
    isVerified: true
  },
  {
    id: 6,
    title: "Elden Ring",
    image: "https://images.unsplash.com/photo-1552820728-8b83bb6b2b0d?w=800&h=500&fit=crop",
    category: "Games",
    version: "v1.09",
    year: 2022,
    size: "60 GB",
    isVerified: true
  },
  {
    id: 7,
    title: "Spotify Desktop",
    image: "https://images.unsplash.com/photo-1614680376593-902f74cf0d41?w=800&h=500&fit=crop",
    category: "Apps",
    version: "v1.2.26",
    year: 2024,
    size: "120 MB",
    isVerified: true
  },
  {
    id: 8,
    title: "Discord",
    image: "https://images.unsplash.com/photo-1614680376408-81e91ffe3db7?w=800&h=500&fit=crop",
    category: "Apps",
    version: "v1.0.9024",
    year: 2024,
    size: "180 MB",
    isVerified: true
  }
]

const recentApps: AppData[] = [
  {
    id: 9,
    title: "Red Dead Redemption 2",
    image: "https://images.unsplash.com/photo-1493711662062-fa541f7f3d24?w=800&h=500&fit=crop",
    category: "Games",
    version: "v1.0.1436",
    year: 2018,
    size: "150 GB",
    isVerified: true
  },
  {
    id: 10,
    title: "Blender 4.0",
    image: "https://images.unsplash.com/photo-1618005198919-d3d4b5a92ead?w=800&h=500&fit=crop",
    category: "Software",
    version: "v4.0",
    year: 2024,
    size: "450 MB",
    isVerified: true
  },
  {
    id: 11,
    title: "Notion Desktop",
    image: "https://images.unsplash.com/photo-1611532736597-de2d4265fba3?w=800&h=500&fit=crop",
    category: "Apps",
    version: "v3.1.0",
    year: 2024,
    size: "200 MB",
    isVerified: true
  },
  {
    id: 12,
    title: "Figma Desktop",
    image: "https://images.unsplash.com/photo-1581291518633-83b4ebd1d83e?w=800&h=500&fit=crop",
    category: "Software",
    version: "v116.15",
    year: 2024,
    size: "280 MB",
    isVerified: true
  },
  {
    id: 13,
    title: "Hogwarts Legacy",
    image: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&h=500&fit=crop",
    category: "Games",
    version: "v1.0.3",
    year: 2023,
    size: "85 GB",
    isVerified: true
  },
  {
    id: 14,
    title: "OBS Studio",
    image: "https://images.unsplash.com/photo-1598550476439-6847785fcea6?w=800&h=500&fit=crop",
    category: "Software",
    version: "v30.0",
    year: 2024,
    size: "180 MB",
    isVerified: true
  },
  {
    id: 15,
    title: "Slack Desktop",
    image: "https://images.unsplash.com/photo-1563986768609-322da13575f3?w=800&h=500&fit=crop",
    category: "Apps",
    version: "v4.35",
    year: 2024,
    size: "250 MB",
    isVerified: true
  },
  {
    id: 16,
    title: "DaVinci Resolve",
    image: "https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=800&h=500&fit=crop",
    category: "Software",
    version: "v18.6",
    year: 2024,
    size: "3.5 GB",
    isVerified: true
  }
]

export function AppGrid() {
  const [activeCategory, setActiveCategory] = useState("all")

  const filterApps = (apps: AppData[]) => {
    if (activeCategory === "all") return apps
    return apps.filter(app => app.category.toLowerCase() === activeCategory)
  }

  const filteredTrending = filterApps(trendingApps)
  const filteredRecent = filterApps(recentApps)

  return (
    <section className="container mx-auto px-4 py-12">
      {/* Filter */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <h2 className="text-2xl font-bold text-foreground">Browse Apps</h2>
        <CategoryFilter 
          activeCategory={activeCategory} 
          onCategoryChange={setActiveCategory} 
        />
      </div>

      {/* Trending Section */}
      <div className="mb-12">
        <div className="flex items-center gap-2 mb-6">
          <TrendingUp className="h-5 w-5 text-primary" />
          <h3 className="text-lg font-semibold text-foreground">Trending</h3>
        </div>
        
        {filteredTrending.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredTrending.map((app) => (
              <AppCard key={app.id} app={app} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12 text-muted-foreground">
            No apps found in this category
          </div>
        )}
      </div>

      {/* Recent Updates Section */}
      <div>
        <div className="flex items-center gap-2 mb-6">
          <Clock className="h-5 w-5 text-primary" />
          <h3 className="text-lg font-semibold text-foreground">Recent Updates</h3>
        </div>
        
        {filteredRecent.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredRecent.map((app) => (
              <AppCard key={app.id} app={app} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12 text-muted-foreground">
            No apps found in this category
          </div>
        )}
      </div>
    </section>
  )
}
