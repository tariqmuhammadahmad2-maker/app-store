"use client"

import { useRouter, useSearchParams } from "next/navigation"
import { Gamepad2, Monitor, Smartphone, Wrench, Film, Code, LayoutGrid } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

const categories = [
  { slug: '', name: 'All', icon: LayoutGrid },
  { slug: 'games', name: 'Games', icon: Gamepad2 },
  { slug: 'software', name: 'Software', icon: Monitor },
  { slug: 'apps', name: 'Apps', icon: Smartphone },
  { slug: 'tools', name: 'Tools', icon: Wrench },
  { slug: 'media', name: 'Media', icon: Film },
  { slug: 'development', name: 'Development', icon: Code },
]

interface CategoryFilterProps {
  currentCategory?: string
  className?: string
}

export function CategoryFilter({ currentCategory = '', className }: CategoryFilterProps) {
  const router = useRouter()
  const searchParams = useSearchParams()

  const handleCategoryChange = (slug: string) => {
    const params = new URLSearchParams(searchParams.toString())
    if (slug) {
      params.set('category', slug)
    } else {
      params.delete('category')
    }
    params.delete('page') // Reset pagination when changing category
    router.push(`/browse?${params.toString()}`)
  }

  return (
    <div className={cn("flex flex-wrap gap-2", className)}>
      {categories.map((category) => {
        const Icon = category.icon
        const isActive = currentCategory === category.slug
        
        return (
          <Button
            key={category.slug}
            variant={isActive ? "default" : "outline"}
            size="sm"
            onClick={() => handleCategoryChange(category.slug)}
            className={cn(
              "gap-2 transition-all",
              isActive 
                ? "bg-primary text-primary-foreground" 
                : "bg-secondary/50 border-border hover:bg-secondary hover:border-primary/50"
            )}
          >
            <Icon className="w-4 h-4" />
            {category.name}
          </Button>
        )
      })}
    </div>
  )
}
