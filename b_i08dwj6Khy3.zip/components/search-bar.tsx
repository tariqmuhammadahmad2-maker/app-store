"use client"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Search, X, SlidersHorizontal } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover"
import { Label } from "@/components/ui/label"

interface SearchBarProps {
  className?: string
  showFilters?: boolean
}

export function SearchBar({ className, showFilters = true }: SearchBarProps) {
  const router = useRouter()
  const searchParams = useSearchParams()
  
  const [query, setQuery] = useState(searchParams.get('q') || '')
  const [platform, setPlatform] = useState(searchParams.get('platform') || '')
  const [sort, setSort] = useState(searchParams.get('sort') || 'newest')

  useEffect(() => {
    setQuery(searchParams.get('q') || '')
    setPlatform(searchParams.get('platform') || '')
    setSort(searchParams.get('sort') || 'newest')
  }, [searchParams])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    updateURL({ q: query })
  }

  const updateURL = (updates: Record<string, string>) => {
    const params = new URLSearchParams(searchParams.toString())
    
    Object.entries(updates).forEach(([key, value]) => {
      if (value) {
        params.set(key, value)
      } else {
        params.delete(key)
      }
    })
    
    params.delete('page') // Reset pagination
    router.push(`/browse?${params.toString()}`)
  }

  const clearSearch = () => {
    setQuery('')
    updateURL({ q: '' })
  }

  const handlePlatformChange = (value: string) => {
    setPlatform(value)
    updateURL({ platform: value === 'all' ? '' : value })
  }

  const handleSortChange = (value: string) => {
    setSort(value)
    updateURL({ sort: value })
  }

  return (
    <div className={className}>
      <div className="flex flex-col sm:flex-row gap-3">
        <form onSubmit={handleSearch} className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search for apps, games, software..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="pl-10 pr-10 h-12 bg-secondary border-border text-foreground placeholder:text-muted-foreground focus:border-primary"
          />
          {query && (
            <button
              type="button"
              onClick={clearSearch}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </form>

        {showFilters && (
          <div className="flex gap-2">
            <Select value={sort} onValueChange={handleSortChange}>
              <SelectTrigger className="w-36 h-12 bg-secondary border-border">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent className="bg-popover border-border">
                <SelectItem value="newest">Newest</SelectItem>
                <SelectItem value="popular">Most Popular</SelectItem>
                <SelectItem value="rating">Highest Rated</SelectItem>
              </SelectContent>
            </Select>

            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" size="icon" className="h-12 w-12 bg-secondary border-border">
                  <SlidersHorizontal className="w-5 h-5" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-64 bg-popover border-border" align="end">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label className="text-foreground">Platform</Label>
                    <Select value={platform || 'all'} onValueChange={handlePlatformChange}>
                      <SelectTrigger className="bg-secondary border-border">
                        <SelectValue placeholder="All platforms" />
                      </SelectTrigger>
                      <SelectContent className="bg-popover border-border">
                        <SelectItem value="all">All Platforms</SelectItem>
                        <SelectItem value="Windows">Windows</SelectItem>
                        <SelectItem value="macOS">macOS</SelectItem>
                        <SelectItem value="Linux">Linux</SelectItem>
                        <SelectItem value="Android">Android</SelectItem>
                        <SelectItem value="iOS">iOS</SelectItem>
                        <SelectItem value="Web">Web</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </PopoverContent>
            </Popover>
          </div>
        )}
      </div>
    </div>
  )
}
